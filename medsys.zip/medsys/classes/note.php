<?php

class Note {
    
    // Properties
    public $noteID;
    public $name;
    
    private $table_name = 'Note';
    
    // Methods
    public function find ($value) {
        $obj = new Note;
        if ($value != null) {
            include ('config/connect_to_db.php');
            $sql_query = $conn->query("select * from ".$obj->table_name." where noteID='" . $value. "'");
            if ($sql_query->num_rows > 0) {
                $row = $sql_query->fetch_assoc();
                $obj->noteID = $row['noteID'];
                $obj->test_session = $row['test_session'];
                $obj->note = $row['note'];
                $obj->med = $row['med'];
            }
        }
        return $obj;
    }
    
    public function all () {
        $obj = new Note;
        include ('config/connect_to_db.php');
        $sql_query = $conn->query("select * from ".$obj->table_name);
        $all_rows = [];
        while ($row = $sql_query->fetch_assoc()) {
            $row_obj = new Note;
            $row_obj->noteID = $row['noteID'];
            $row_obj->test_session = $row['test_session'];
            $row_obj->note = $row['note'];
            $row_obj->med = $row['med'];
            $all_rows[] = $row_obj;
        }
        return $all_rows;
    }
    
    public function save () {
        include ('config/connect_to_db.php');
        if (empty($this->noteID)) {
            $sql_query = $conn->query("insert into ".$this->table_name." (test_session,note,med) values ('".$this->test_session."', '".$this->note."', '".$this->med."')");
            $this->noteID = $conn->insert_id;
        } else {
            $sql_query = $conn->query("update ".$this->table_name." set test_session='".$this->test_session."', note='".$this->note."', med='".$this->med."' where noteID='".$this->noteID."'");
        }
    }
    
}


?>