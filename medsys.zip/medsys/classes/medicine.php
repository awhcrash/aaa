<?php

class Medicine {
    
    // Properties
    public $medicineID;
    public $name;
    
    private $table_name = 'Medicine';
    
    // Methods
    
    public function find ($value) {
        $obj = new Medicine;
        if ($value != null) {
            include ('config/connect_to_db.php');
            $sql_query = $conn->query("select * from ".$obj->table_name." where medicineID='" . $value. "'");
            if ($sql_query->num_rows > 0) {
                $row = $sql_query->fetch_assoc();
                $obj->medicineID = $row['medicineID'];
                $obj->name = $row['name'];
            }
        }
        return $obj;
    }
    
    public function all () {
        $obj = new Medicine;
        include ('config/connect_to_db.php');
        $sql_query = $conn->query("select * from ".$obj->table_name);
        $all_rows = [];
        while ($row = $sql_query->fetch_assoc()) {
            $row_obj = new Medicine;
            $row_obj->medicineID = $row['medicineID'];
            $row_obj->name = $row['name'];
            $all_rows[] = $row_obj;
        }
        return $all_rows;
    }
    
    public function save () {
        include ('config/connect_to_db.php');
        if (empty($this->medicineID)) {
            $sql_query = $conn->query("insert into ".$this->table_name." (name) values ('".$this->name."')");
            $this->medicineID = $conn->insert_id;
        } else {
            $sql_query = $conn->query("update ".$this->table_name." set name='".$this->name."' where medicineID='".$this->medicineID."'");
        }
    }
    
}


?>