<?php

class User {
    
    // Properties
    public $userID;
    public $username;
    public $email;
    public $password;
    public $organization;
    public $role;
    public $latlng;
    
    private $table_name = 'User';
    
    // Methods
    
    public function find ($value) {
        $obj = new User;
        if ($value != null) {
            include ('config/connect_to_db.php');
            $sql_query = $conn->query("select * from ".$obj->table_name." where userID='" . $value. "' or username='" . $value . "' or email='" . $value . "'");
            if ($sql_query->num_rows > 0) {
                $user = $sql_query->fetch_assoc();
                $obj->userID = $user['userID'];
                $obj->username = $user['username'];
                $obj->password = $user['password'];
                $obj->email = $user['email'];
                $obj->organization = $user['organization'];
                $obj->role = $user['role'];
                $obj->latlng = $user['latlng'];
            }
        }
        return $obj;
    }
    
    public function all ($where = '') {
        $user = new User;
        include ('config/connect_to_db.php');
        $sql_query = $conn->query("select * from ".$user->table_name.' '.$where);
        $all_rows = [];
        while ($user = $sql_query->fetch_assoc()) {
            $user_obj = new User;
            $user_obj->userID = $user['userID'];
            $user_obj->username = $user['username'];
            $user_obj->email = $user['email'];
            $user_obj->password = $user['password'];
            $user_obj->organization = $user['organization'];
            $user_obj->role = $user['role'];
            $user_obj->latlng = $user['latlng'];
            $all_rows[] = $user_obj;
        }
        return $all_rows;
    }
    
    public function save () {
        include ('config/connect_to_db.php');
        if (empty($this->userID)) {
            $sql_query = $conn->query("insert into ".$this->table_name." (username, email, password, organization, role, latlng) values ('".$this->username."', '".$this->email."', '".$this->password."', '".$this->organization."', '".$this->role."', '".$this->latlng."')");
            $this->userID = $conn->insert_id;
        } else {
            $sql_query = $conn->query("update ".$this->table_name." set username='".$this->username."' , email='".$this->email."' , password='".$this->password."' , organization='".$this->organization."' , role='".$this->role."' , latlng='".$this->latlng."' where userID='".$this->userID."'");
        }
    }
    
}


?>