<?php

class Therapy {
    
    // Properties
    public $therapyID;
    public $name;
    
    private $table_name = 'Therapy';
    
    // Methods
    
    public function find ($value) {
        $obj = new Therapy;
        if ($value != null) {
            include ('config/connect_to_db.php');
            $sql_query = $conn->query("select * from ".$obj->table_name." where therapyID='" . $value. "'");
            if ($sql_query->num_rows > 0) {
                $row = $sql_query->fetch_assoc();
                $obj->therapyID = $row['therapyID'];
                $obj->med = $row['med'];
                $obj->patient = $row['patient'];
                $obj->therapylist = $row['therapylist'];
            }
        }
        return $obj;
    }
    
    public function all () {
        $obj = new Therapy;
        include ('config/connect_to_db.php');
        $sql_query = $conn->query("select * from ".$obj->table_name);
        $all_rows = [];
        while ($row = $sql_query->fetch_assoc()) {
            $row_obj = new Therapy;
            $row_obj->therapyID = $row['therapyID'];
            $row_obj->med = $row['med'];
            $row_obj->patient = $row['patient'];
            $row_obj->therapylist = $row['therapylist'];
            $all_rows[] = $row_obj;
        }
        return $all_rows;
    }
    
    public function save () {
        include ('config/connect_to_db.php');
        if (empty($this->therapyID)) {
            $sql_query = $conn->query("insert into ".$this->table_name." (med , patient , therapylist) values ('".$this->med."' , '".$this->patient."' , '".$this->therapylist."')");
            $this->therapyID = $conn->insert_id;
        } else {
            $sql_query = $conn->query("update ".$this->table_name." set med='".$this->med."' , patient='".$this->patient."' therapylist='".$this->therapylist."' where therapyID='".$this->therapyID."'");
        }
    }
    
}


?>