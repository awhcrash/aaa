<?php

class Therapy_List {
    
    // Properties
    public $therapy_listID;
    public $name;
    public $medicine;
    public $Dosage;
    
    private $table_name = 'Therapy_List';
    
    // Methods
    
    public function find ($value) {
        $obj = new Therapy_List;
        if ($value != null) {
            include ('config/connect_to_db.php');
            $sql_query = $conn->query("select * from ".$obj->table_name." where therapy_listID='" . $value. "'");
            if ($sql_query->num_rows > 0) {
                $obj = $sql_query->fetch_assoc();
                $obj->therapy_listID = $row['therapy_listID'];
                $obj->name = $row['name'];
                $obj->medicine = $row['medicine'];
                $obj->Dosage = $row['Dosage'];
            }
        }
        return $obj;
    }
    
    public function all () {
        $obj = new Therapy_List;
        include ('config/connect_to_db.php');
        $sql_query = $conn->query("select * from ".$obj->table_name);
        $all_rows = [];
        while ($row = $sql_query->fetch_assoc()) {
            $row_obj = new Therapy_List;
            $row_obj->therapy_listID = $row['therapy_listID'];
            $row_obj->name = $row['name'];
            $row_obj->medicine = $row['medicine'];
            $row_obj->Dosage = $row['Dosage'];
            $all_rows[] = $row_obj;
        }
        return $all_rows;
    }
    
    public function save () {
        include ('config/connect_to_db.php');
        if (empty($this->therapy_listID)) {
            $sql_query = $conn->query("insert into ".$this->table_name." (name , medicine , Dosage) values ('".$this->name."', '".$this->medicine."', '".$this->Dosage."')");
            $this->therapy_listID = $conn->insert_id;
        } else {
            $sql_query = $conn->query("update ".$this->table_name." set name='".$this->name."', medicine='".$this->medicine."', Dosage='".$this->Dosage."' where therapy_listID='".$this->therapy_listID."'");
        }
    }
    
}


?>