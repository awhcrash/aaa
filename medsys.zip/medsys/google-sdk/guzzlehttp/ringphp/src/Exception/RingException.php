<?php
namespace GuzzleHttp\Ring\Exception;

class RingException extends \RuntimeException {};
