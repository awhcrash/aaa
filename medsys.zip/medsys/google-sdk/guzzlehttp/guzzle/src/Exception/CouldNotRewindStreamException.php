<?php
namespace GuzzleHttp\Exception;

class CouldNotRewindStreamException extends RequestException {}
