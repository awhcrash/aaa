<?php

$loader = require __DIR__.'/../vendor/autoload.php';
$loader->add('React\Promise', __DIR__);
