<?php

function youtube_search ($apiKey, $maxResults, $searchQuery) {
    return json_decode(file_get_contents('https://www.googleapis.com/youtube/v3/search?q='.$searchQuery.'&key='.$apiKey.'&part=snippet&&maxResults='.$maxResults), true);
}