<?php 

$auth_role = Role::find($auth->role);

$page = 'home.php';


if (isset($_GET['action'])) {
    
    $action = $_GET['action'];
    
    if ($auth->role == 3) {
        if ($action == 'view_videos') {
            $page = 'youtube_videos.php';
        } else if ($action == 'account_settings') {
            $page = 'patient_account.php';
        } else if ($action == 'save_location') {
            
            if (isset($_GET['latlng'])) {
                $auth->latlng = $_GET['latlng'];
                $auth->save();
            }
            
            header('Location: index.php?action=account_settings');
            exit();
        }  else if ($action == 'add_exercise') {
            $page = 'add_exercise.php';
            
            
        }
        else if ($action == 'add_exercise1') {
            $page = 'add_exercise1.php';
        }
        else if ($action == 'add_exercise2') {
            $page = 'add_exercise2.php';
        }
        else if ($action == 'add_exercise3') {
            $page = 'add_exercise3.php';
        }
        else if ($action == 'add_exercise5') {
            $page = 'add_exercise5.php';
        }
    } else if ($auth->role == 1 || $auth->role == 2) {
        if ($action == 'view_patients') {
            $page = 'view_patients.php';
        }
    } 
}

include ('theme/header.php');
include('theme/navbar.php');
include('theme/'.$page);
include ('theme/footer.php');


?>