<?php

if ($auth->role == 3) {
    print 'This some videos about the Parkinson’s Disease (PD)
exercises. '.'<br>';

<iframe width="560" height="315" src="https://www.youtube.com/embed/ikY9WpmekRY" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
  
    
    
}

















?>