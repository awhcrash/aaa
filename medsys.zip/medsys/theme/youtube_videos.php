<?php

include ('youtube_api.php');

$search_query = str_replace(' ', '+', 'Parkinson’s Disease (PD) exercises');

$videos_search = youtube_search('AIzaSyB4_pC_kJ5_v2FhetWSv1y-ZzhmIfC6sEw', 50, $search_query);
$search_list = $videos_search['items'];

?>

<style>
       
       h5 {
  color: white;
       }
    
    </style>

<div class="container text-center">

    <h3>Recommended Videos From Youtube</h3>
    
    <br>
    
    <div class="row mt-5">
        
        <?php foreach ($search_list as $item) : ?>
        <div class="col-md-4 text-left mb-5">
            <a href="https://www.youtube.com/watch?v=<?php print $item['id']['videoId']; ?>" target="_blank">
                <div class="media">
                    <img src="<?php print $item['snippet']['thumbnails']['default']['url']; ?>" class="mr-3" alt="...">
                    <div class="media-body">
                        <h5 class="mt-0"><?php print $item['snippet']['title']; ?></h5>
                    </div>
                </div>
            </a>
        </div>
        <?php endforeach; ?>
        
    </div>
</div>