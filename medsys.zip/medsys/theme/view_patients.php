<?php 

$patients_list = User::all('where role=3');

?>

<div class="container">
    
    <table class="table">

        <thead>
            <tr>
                <th scope="col">userID</th>
                <th scope="col">Username</th>
                <th scope="col">Email</th>
                <th scope="col">Location</th>
            </tr>
        </thead>

        <tbody>
            <?php foreach ($patients_list as $p) : ?>
            <tr>
                <th scope="row"><?php print $p->userID; ?></th>
                <td><?php print $p->username; ?></td>
                <td><?php print $p->email; ?></td>
                <td>
                    <?php if (empty($p->latlng)) : ?>
                    -
                    <?php else : ?>
                    <a class="btn btn-primary" href="https://www.google.com/maps/@<?php print $p->latlng; ?>,12z" target="_blank">Location</a>
                    <?php endif; ?>
                </td>
            </tr>
            <?php endforeach; ?>
        </tbody>

    </table>
</div>