<style>
       
       h2 {
  color: white;
       }
    
    

 
    

    
    </style>






<h2 class="text-center"> Welcome <?php print $auth_role->name.' '.$auth->username; ?></h2>
<?php include ('theme/oclock.php'); ?>
    
<?php include ('theme/add_exercise4.php'); ?>



<?php if ($auth->role == 3) : ?>

    

<?php endif; ?>