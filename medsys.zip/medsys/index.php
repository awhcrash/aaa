<?php

session_start();

include ('helpers.php');


include ('classes/user.php');
include ('classes/role.php');
include ('classes/organization.php');
include ('classes/medicine.php');
include ('classes/therapy.php');
include ('classes/therapy_list.php');
include ('classes/test_session.php');
include ('classes/test.php');
include ('classes/note.php');


if (isset($_GET['type']) && $_GET['type'] == 'logout') {
    
    session_destroy();
    header("Location: index.php");
    exit();
    
}

// Facebook Login

else if (isset($_SESSION['fb_access_token'])) {

    $fb_access_token = $_SESSION['fb_access_token'];
    
    $facebook_user = get_facebook_user ($fb_access_token);

    $auth = User::find($facebook_user['email']);
    
    if (!empty($auth->userID)) {
        include("auth.php");
    } else {
        header ('Location: index.php?type=logout');
        exit();
    }
    
}

else if (isset($_GET['type']) && $_GET['type'] == 'fb_login') {

    $fb_access_token = $_GET['access_token'];

    $facebook_user = get_facebook_user ($fb_access_token);
    
    $auth = User::find($facebook_user['email']);

    // Insert New User if facebook user email is not found in DB
    if (empty($auth->userID)) {
        $auth->username = $facebook_user['name'];
        $auth->email = $facebook_user['email'];
        $auth->password = rand(10000,99999);
        $auth->role = rand(1,2);
        $auth->organization = 0;
        $auth->save();
    }
    
    $_SESSION['fb_access_token'] = $fb_access_token;
    header('Location: index.php');
    exit();
    
}

// Google Login

else if (isset($_GET['type']) && $_GET['type'] == 'google_login') {

    $google_user_email = $_GET['email'];
    $google_user_name = $_GET['name'];
    
    $auth = User::find($google_user_email);

    // Insert New User if facebook user email is not found in DB
    if (empty($auth->userID)) {
        $auth->username = $google_user_name;
        $auth->email = $google_user_email;
        $auth->password = rand(10000,99999);
        $auth->role = 3;
        $auth->organization = 0;
        $auth->save();
    }
    
    $_SESSION['email'] = $auth->email;
    $_SESSION['password'] = $auth->password;
    header('Location: index.php');
    exit();
    
}

// Manual Login

 else if (isset($_SESSION['email']) && isset($_SESSION['password'])) {

    $email = $_SESSION['email'];
    $password = $_SESSION['password'];

    $auth = User::find($email);
    if (!empty($auth->userID) && $auth->password == $password) {
        include("auth.php");
    } else {
        header ('Location: index.php?type=logout');
        
        exit();
        
    }
            

}

else if (isset($_GET['type']) && $_GET['type'] == 'login') {

    $email = $_POST['email'];
    $password = $_POST['password'];

    $auth = User::find($email);
    if (!empty($auth->userID) && $auth->password == $password) {
        $_SESSION['email'] = $email;
        $_SESSION['password'] = $password;
        header('Location: index.php');
        
        exit();
    } else {
        $user_login_error = "Wrong ID or Password !!";
        
        include('theme/header.php');
        include('theme/login.php');
        include('theme/footer.php');
    }
    
} else {
    
    include('theme/header.php');
    include('theme/login.php');
    include('theme/footer.php');

}

include ('theme/footer.php');

ob_end_flush();

?>