<?php

include ('classes/user.php');

$user = new User;

$user->username = 'aaaaaaaa';
$user->email = 'vvv';
$user->password = 'aaa';
$user->role = '3';
$user->organization = 0;

$user->save();
 
?>