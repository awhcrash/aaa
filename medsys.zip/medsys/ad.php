<?php  

$e1 = 0;

else if ($action == 'add_exercise') {
            $page = 'add_exercise.php';
            $e1 = e1 + 1;
    
    
        }