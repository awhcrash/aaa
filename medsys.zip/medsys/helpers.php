<?php

function get_facebook_user ($auth_token) {

    include ('facebook-sdk/autoload.php');

    $fb = new Facebook\Facebook([
      'app_id' => '434279380560964',
      'app_secret' => 'b5b45b5426108203aa43a4c47ce60faf',
      'default_graph_version' => 'v4.0',
      ]);

    try {
        // Returns a `Facebook\FacebookResponse` object
        $response = $fb->get('/me?fields=id,name,email', $auth_token);
    } catch(Facebook\Exceptions\FacebookResponseException $e) {
        echo 'Graph returned an error: ' . $e->getMessage();
        exit;
    } catch(Facebook\Exceptions\FacebookSDKException $e) {
        echo 'Facebook SDK returned an error: ' . $e->getMessage();
        exit;
    }
    
    return $response->getGraphUser();    
}

function get_google_user ($id_token) {

    require_once 'google-sdk/autoload.php';

    $client = new Google_Client(['client_id' => '532047635270-kmo56stahmf22m6k7ahrr3jq2ae62bp3.apps.googleusercontent.com']);  // Specify the CLIENT_ID of the app that accesses the backend
    $payload = $client->verifyIdToken($id_token);
    
    if ($payload) {
        return $payload;
    } else {
        return ;
    }   
}
 
?>